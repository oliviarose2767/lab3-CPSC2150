package cpsc2150.lab3;

public interface ISet {

    /**
     *
     * @param val is the value to be
     *            added to the set
     * @pre
     * MIN_VALUE < val < MAX_VALUE
     * @post
     *
     */
    void add(Integer val);

    /**
     *
     * @param pos is a position in the set
     * @return the value removed
     * @pre
     * pos > 0 && getSize() != 0
     * @post
     */
    Integer removePos(int pos);

    /**
     *
     * @param val, a value supposedly in set
     * @return returns true if int val is
     *         present in the set
     * @pre
     * val is a valid input int
     * @post
     * true or false will be returned
     */
    boolean contains(Integer val);

    /**
     *
     * @return returns the size of the set
     * @pre
     * none
     * @post
     * 0 <= return <= 100
     */
    int getSize();

}
