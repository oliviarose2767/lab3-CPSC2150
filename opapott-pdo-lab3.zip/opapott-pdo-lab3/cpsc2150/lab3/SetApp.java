/*
 * Lab 3: Phillip Do, Olivia Papotto
 */

package cpsc2150.lab3;

import java.util.*;

public class SetApp{

    public static void main(String[] args){

        System.out.println("Enter 1 for array implementation or 2 for a list implementation");

        Scanner scanner = new Scanner(System.in);

        int input = Integer.parseInt(scanner.nextLine());

        while((input < 1) || (input > 2)){
            System.out.println("Invalid! Must be 1 or 2. Try again!");
            input = Integer.parseInt(scanner.nextLine());
        }

        printMenu();

        int option = Integer.parseInt(scanner.nextLine());

        ArraySet arr = new ArraySet();
        ListSet list = new ListSet();

        /*
         *  input = 1 = array
         *  input = 2 = list
         *
         *  option = 1 = add
         *  option = 2 = remove
         */
        while(option != 3){

            if(input == 1 && option == 1){
                System.out.println("What value to add to set?");

                Scanner in = new Scanner(System.in);
                Integer number = in.nextInt();

                addArray(arr, number);
            }

            if(input == 2 && option == 1){
                System.out.println("What value to add to set?");

                Scanner in = new Scanner(System.in);
                int number = in.nextInt();

                addList(list,number);
            }

            if(input == 1 && option == 2){

                Scanner in = new Scanner(System.in);

                if(arr.isEmpty()){
                    System.out.println("Can't remove from an empty set!");
                    System.out.println(arr.toString());
                }else {

                    System.out.println("What position should be removed from the set?");
                    Integer pos = in.nextInt();

                    while (pos < 0 || pos >= arr.getSize()) {
                        System.out.println("That's not a valid position");
                        System.out.println("What position should be removed from the set?");
                        pos = Integer.parseInt(scanner.nextLine());
                    }

                    arr.removePos(pos);
                    System.out.println(arr.toString());

                }

            }


            if(input == 2 && option == 2){

                Scanner in = new Scanner(System.in);

                if(list.isEmpty()){
                    System.out.println("Can't remove from an empty set!");
                    System.out.println(arr.toString());
                }else{

                    System.out.println("What position should be removed from the set?");
                    int number = in.nextInt();

                    while(number < 0 || number >= list.getSize() ) {

                        System.out.println("That's not a valid position");
                        System.out.println("What position should be removed from the set?");
                        number = Integer.parseInt(scanner.nextLine());

                    }

                    list.removePos(number);
                    System.out.println(list.toString());

                }

            }

            printMenu();
            option = Integer.parseInt(scanner.nextLine());

        }


    }

    private static void printMenu(){
        System.out.println("1. Add a value to the set");
        System.out.println("2. Remove a value from the set");
        System.out.println("3. Exit");
    }

    private static void addArray(ArraySet obj, Integer val){
        //check if value is already in array
        if(!obj.contains(val)){
            obj.add(val);
            System.out.println(obj.toString());
        }else{
            System.out.println("That value is already in the set.");
            System.out.println(obj.toString());
        }
    }

    private static void addList(ListSet obj, Integer val){
        //check if val is already in set
        if(!obj.contains(val)){
            obj.add(val);
            System.out.println(obj.toString());
        }else{
            System.out.println("That value is already in the set.");
            System.out.println(obj.toString());
        }

    }

}

