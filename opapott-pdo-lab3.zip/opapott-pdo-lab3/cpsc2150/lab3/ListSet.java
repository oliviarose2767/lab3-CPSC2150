package cpsc2150.lab3;

import java.util.*;

/**
 * @invariants ListSet size cannot 
 *             exceed a maximum of 100
 *             integers and ListSet 
 *             !contain the same value twice
 */
public class ListSet {

    private List<Integer> listset;

    ListSet(){
        listset = new ArrayList<Integer>();
    }

    void add(Integer val){
        listset.add(val);
    }

    Integer removePos(int pos){

        Integer num = listset.get(pos);
        listset.remove(pos);

        return num;

    }

    boolean contains(Integer val){

        for(int i = 0; i < listset.size(); i++){
            int num = listset.get(i);

            if(num == val){return true;}

        }
        return false;

    }

    int getSize(){

        return listset.size();

    }

    public boolean isEmpty(){
        return listset.isEmpty();
    }

    /**
     *
     * @return a string with a representation of the set
     * @post toString = ""
     */
    @Override
    public String toString(){

        String s = null;

        s = "Set is: \n";


        for(int i = 0; i < listset.size(); i++){
            s += listset.get(i) + ", ";
        }

        return s;

    }

}

